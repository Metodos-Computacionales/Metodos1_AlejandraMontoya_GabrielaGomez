#!usr/bin/env bash
echo "la lista de directorios es:">>problema1.txt
ls>>problema1.txt
echo "El numero de archivos y directorios es:">>problema1.txt
ls | wc -l >>problema1.txt
echo "El numero de caracteres que hay en la lista es:">>problema1.txt
ls | wc -m>>problema1.txt
mkdir mydirectory 
ls>>problema1.txt
echo "La nueva lista de archivos y directorios es:">>problema1.txt
ls -d*/>>problema1.txt
echo "El nuevo numero de archivos y directorios es:">>problema1.txt
ls -d*/| wc -l >>problema1.txt
#Parte 2 
echo "el numero total de estudiantes es:">>problema2.txt
wc -l 01_notas.tsv>>problema2.txt
echo "el numero total de estudiantes de ingenieria es:">>problema2.txt
grep "ING" 01_notas.tsv | wc -l >>problema2.txt